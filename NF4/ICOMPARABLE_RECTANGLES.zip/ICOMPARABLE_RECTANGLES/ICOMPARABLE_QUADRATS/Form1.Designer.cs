﻿namespace ICOMPARABLE_RECTANGLES
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOrdenarNom = new System.Windows.Forms.Button();
            this.dvRectangles = new System.Windows.Forms.DataGridView();
            this.btnOrdenarX = new System.Windows.Forms.Button();
            this.btnOrdenarAmplada = new System.Windows.Forms.Button();
            this.btnOrdenarArea = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dvRectangles)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOrdenarNom
            // 
            this.btnOrdenarNom.Location = new System.Drawing.Point(12, 12);
            this.btnOrdenarNom.Name = "btnOrdenarNom";
            this.btnOrdenarNom.Size = new System.Drawing.Size(97, 51);
            this.btnOrdenarNom.TabIndex = 0;
            this.btnOrdenarNom.Text = "ORDENAR PER NOM";
            this.btnOrdenarNom.UseVisualStyleBackColor = true;
            // 
            // dvRectangles
            // 
            this.dvRectangles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvRectangles.Location = new System.Drawing.Point(12, 69);
            this.dvRectangles.Name = "dvRectangles";
            this.dvRectangles.Size = new System.Drawing.Size(494, 369);
            this.dvRectangles.TabIndex = 1;
            // 
            // btnOrdenarX
            // 
            this.btnOrdenarX.Location = new System.Drawing.Point(115, 12);
            this.btnOrdenarX.Name = "btnOrdenarX";
            this.btnOrdenarX.Size = new System.Drawing.Size(97, 51);
            this.btnOrdenarX.TabIndex = 2;
            this.btnOrdenarX.Text = "ORDENAR PER X";
            this.btnOrdenarX.UseVisualStyleBackColor = true;
            // 
            // btnOrdenarAmplada
            // 
            this.btnOrdenarAmplada.Location = new System.Drawing.Point(218, 12);
            this.btnOrdenarAmplada.Name = "btnOrdenarAmplada";
            this.btnOrdenarAmplada.Size = new System.Drawing.Size(97, 51);
            this.btnOrdenarAmplada.TabIndex = 3;
            this.btnOrdenarAmplada.Text = "ORDENAR PER AMPLADA";
            this.btnOrdenarAmplada.UseVisualStyleBackColor = true;
            // 
            // btnOrdenarArea
            // 
            this.btnOrdenarArea.Location = new System.Drawing.Point(321, 12);
            this.btnOrdenarArea.Name = "btnOrdenarArea";
            this.btnOrdenarArea.Size = new System.Drawing.Size(97, 51);
            this.btnOrdenarArea.TabIndex = 4;
            this.btnOrdenarArea.Text = "ORDENAR PER AREA";
            this.btnOrdenarArea.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 450);
            this.Controls.Add(this.btnOrdenarArea);
            this.Controls.Add(this.btnOrdenarAmplada);
            this.Controls.Add(this.btnOrdenarX);
            this.Controls.Add(this.dvRectangles);
            this.Controls.Add(this.btnOrdenarNom);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dvRectangles)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOrdenarNom;
        private System.Windows.Forms.DataGridView dvRectangles;
        private System.Windows.Forms.Button btnOrdenarX;
        private System.Windows.Forms.Button btnOrdenarAmplada;
        private System.Windows.Forms.Button btnOrdenarArea;
    }
}

