﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ICOMPARABLE_RECTANGLES
{
    public partial class Form1 : Form
    {
        private List<Rectangle> rectangles;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rectangles = LlegirRectangles();
            MostrarDadesDataGrid();
        }

        private void MostrarDadesDataGrid()
        {
            this.dvRectangles.DataSource = rectangles.ToArray();
        }

        private List<Rectangle> LlegirRectangles()
        {
            throw new NotImplementedException();
        }

    }
}
